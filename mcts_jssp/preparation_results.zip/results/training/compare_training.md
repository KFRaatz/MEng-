Training styles on the validation instances (Cmax / LB0; greedy = entropy 0, sampled = temperature 1, 4 samples per instance; entropy of the policy at temperature 1, 1 = uniform; p: two-sided Wilcoxon signed-rank tests of the two styles on the same instances)

| model | style | status | start | iterations | stopped_by | minutes | greedy | sampled | uniform | mwkr | greedy_vs_uniform_pct | entropy | p_greedy | p_sampled |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| lr_6x6 | self-labelling | trained | random | 20 | no_improvement | 0.8 | 1.3930 | 1.5476 | 1.5814 | 1.4240 | 11.9 | 0.999 | 0.5300 | 0.0012 |
| lr_6x6 | self-play | trained | random | 10 | no_improvement | 0.4 | 1.3984 | 1.5692 | 1.5814 | 1.4240 | 11.6 | 1.000 | 0.5300 | 0.0012 |
| lr_10x10 | self-labelling | trained | lr_6x6 | 50 | iterations | 5.9 | 1.5017 | 1.6393 | 1.6953 | 1.5052 | 11.4 | 0.993 | 0.0000 | 0.0000 |
| lr_10x10 | self-play | trained | random | 10 | no_improvement | 1.2 | 1.7086 | 1.6872 | 1.6953 | 1.5052 | -0.8 | 1.000 | 0.0000 | 0.0000 |
| lr_15x15 | self-labelling | trained | lr_10x10 | 20 | no_improvement | 8.1 | 1.5547 | 1.7081 | 1.7661 | 1.5644 | 12.0 | 0.996 | 0.0000 | 0.0000 |
| lr_15x15 | self-play | trained | random | 10 | no_improvement | 3.6 | 1.8528 | 1.7671 | 1.7661 | 1.5644 | -4.9 | 1.000 | 0.0000 | 0.0000 |
| az_6x6 | self-labelling | trained | lr_6x6 | 42 | no_improvement | 1.3 | 1.4077 | 1.4436 | 1.5814 | 1.4240 | 11.0 | 0.665 | 0.0000 | 0.0000 |
| az_6x6 | self-play | trained | random | 10 | no_improvement | 0.3 | 1.6931 | 1.5757 | 1.5814 | 1.4240 | -7.1 | 0.999 | 0.0000 | 0.0000 |
| az_10x10 | self-labelling | trained | lr_10x10 | 28 | no_improvement | 2.2 | 1.5602 | 1.5989 | 1.6953 | 1.5052 | 8.0 | 0.841 | 0.0000 | 0.0000 |
| az_10x10 | self-play | trained | random | 22 | no_improvement | 1.5 | 1.8424 | 1.7263 | 1.6953 | 1.5052 | -8.7 | 0.957 | 0.0000 | 0.0000 |
| az_15x15 | self-labelling | trained | lr_15x15 | 20 | no_improvement | 3.7 | 1.8314 | 1.7540 | 1.7661 | 1.5644 | -3.7 | 0.990 | 0.0000 | 0.0000 |
| az_15x15 | self-play | trained | random | 17 | no_improvement | 3.3 | 1.9738 | 1.8140 | 1.7661 | 1.5644 | -11.8 | 0.965 | 0.0000 | 0.0000 |
